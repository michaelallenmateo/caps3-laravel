<?php $__env->startSection('title','BeautyTalk | Latest Reviews and Trends on beauty products'); ?>
<?php $__env->startSection('content'); ?>

<style>

table {
    font-family: arial, sans-serif;
    border-collapse: collapse;
    width: 100%;
    font-size: 18px;
}

td, th {
    border: 1px solid #dddddd;
    text-align: center;
    width: auto;
    padding: 5px;
}

img.review-img {
	width: 80px;
	height: 80px;
}


tr {
	width: auto;
}


</style>

<?php if(Session::has('success_message')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('success_message')); ?>

    </div>
    <?php endif; ?>


<div class="container">
		<?php if(count(Auth::user()->reviews)>0): ?>		
	<h1>Your review details are as follows:</h1>

		



<table>
				<tr>
					<th>Date</th>
					<th>Product Name</th>
					<th>Product Image</th>
					<th>Brand Name</th>
					
					<th>Your review</th>
					<th>Your rating</th>
					<th>Review Status</th>
					<th>Actions</th>
				</tr>
		<?php $__currentLoopData = Auth::user()->reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		
				
				
				<tr>
						
						
						<td><?php echo e($review->created_at); ?></td> 
						<td><?php echo e($review->product->name); ?></td> 
						<td><img src="/image/<?php echo e($review->product->image); ?>" class="review-img"></td> 
						<td><?php echo e($review->product->brand); ?></td> 
						
						<td><?php echo e($review->content); ?></td> 
						<td><?php echo e($review->rating); ?> stars</td> 
						<td><?php echo e($review->approved ? 'Approved' : 'Pending'); ?></td> 
						
						<td>	

							<a href="/myreviews/<?php echo e($review->id); ?>/edit" class="btn btn-primary btn-xs">Edit</a>
							<button type="button" class="btn btn-danger btn-xs" data-toggle="modal" data-target="#deleteConfirmation">Delete</button>
						</td>
				</tr>
				
				
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
		<?php else: ?>
		<h4>You dont have any reviews made.</h4>
		<?php endif; ?>


		<!-- Modal for delete-->
			<div id="deleteConfirmation" class="modal fade" role="dialog">
			  <div class="modal-dialog">

			    <!-- Modal content-->
			    <div class="modal-content">
			      <div class="modal-header">
			        <button type="button" class="close" data-dismiss="modal">&times;</button>
			        <h4 class="modal-title">Warning: This action is irreversible !</h4>
			      </div>
			      <div class="modal-body">
			      	Are you sure you want to delete this review?
			      </div>
			      <div class="modal-footer">
			      	<?php if(count(Auth::user()->reviews)>0): ?>		
				        <form method="POST" action="/myreviews/<?php echo e($review->id); ?>/delete">
		        			<?php echo e(csrf_field()); ?>

		        			<?php echo e(method_field('DELETE')); ?>

		        			<button class="btn btn-danger">Proceed</button>
		        			<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
		        		</form>
		        	<?php else: ?>
		        		<form method="POST" action="">
		        			<?php echo e(csrf_field()); ?>

		        			<?php echo e(method_field('DELETE')); ?>

		        			<button class="btn btn-danger">Proceed</button>
		        			<button type="button" class="btn btn-primary" data-dismiss="modal">Cancel</button>
		        		</form>
		        	<?php endif; ?>	
		        			
			      </div>
			    </div>

			  </div>
			</div>


			</table>

</div>
					





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>