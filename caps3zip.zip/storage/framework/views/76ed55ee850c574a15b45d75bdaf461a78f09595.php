<?php $__env->startSection('title','BeautyTalk | Latest Reviews and Trends on beauty products'); ?>
<?php $__env->startSection('content'); ?>
      
      <style type="text/css">
          div.jumbotron {
            padding: 0;
            margin: 0;
            background-image: url(/image/index1.jpg),url(/image/index2.jpg) ;
            background-position: left,right;
            background-repeat: no-repeat, no-repeat;
            background-size: 50% auto;
          }

          div.container.jumbo {
            padding-top: 50px;
            padding-left: 15%;
            background-color: rgba(0,0,0,0.3);
            width: auto;
          }

          h1.display-4,
          p.lead {
            color: rgba(0,0,0,1);
            
          }
          
      </style>  
 
<?php if(Session::has('success_message')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('success_message')); ?>

    </div>
    <?php endif; ?>

    <div class="jumbotron jumbotron-fluid">
  <div class="container jumbo">
    <h1 class="display-4">Let your experience be heard</h1>
    <p class="lead">Be part of BeautyTalk latest reviews and trends on beauty products.</p>
  </div>
</div>


    <div class="container index">
        <div class="row">
            <h2 style="width: auto;text-align: center;">Recently Added</h2>
            <?php if(count($products)>0): ?>
                <?php $__currentLoopData = $products->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="thumbnail">
                        <a href="/products/<?php echo e($product->id); ?>" style="list-style:none;">
                        <div class="col-xs-12">
                            <img src="/storage/image/<?php echo e($product->image); ?>" class="img-responsive">
                        </div>
                        </a>
                        <p><?php echo e($product->name); ?></p>
                        <p><?php echo e($product->brand); ?></p>
                        <p>&#8369 <?php echo e(number_format($product->price, 2)); ?></p>
                        <?php echo e($product->category->title); ?>

                        <div class="ratings">
                            <strong>Rating:</strong>
                            <?php for($i=1; $i <= 5 ; $i++): ?>
                              <span class="glyphicon glyphicon-star<?php echo e(($i <= $product->reviews->where('approved',true)->avg('rating')) ? '' : '-empty'); ?>"></span>
                            <?php endfor; ?>
                            
                            <p><strong><?php echo e(count($product->reviews->where('approved',true))); ?> Reviews</strong></p>
                        </div>
                    </div> 
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h3>No listed products yet under this category</h3>
            <?php endif; ?>    
        </div>
        <div class="text-center">
                  <?php echo e($products->links()); ?>

        </div>
    </div>

    
    <div style="border: 1px solid lightgrey;border-radius: 4px; width: 600px; position: fixed;bottom: 170px; top: auto; right:25%; background-color: #f7f7f7; display: inline-block; padding: 10px;" class="prodReview">
      <h4>Didn't find the product your looking? Submit the product you want to be reviewed.</h4>
      <div> <input type="text" name="prod_forReview" placeholder="Enter product name here"> </div>
      <div>  <button type="submit">Submit</button> </div>
    </div>


    <script type="text/javascript">
     



      $(document).ready( function() {
        $(".prodReview").hide(); //hide your div initially
        var y = $(this).scrollTop();
           $(window).scroll(function() {
             if($(window).scrollTop() > 1200) {
              $('.prodReview').fadeIn();
              } else {
              $('.prodReview').fadeOut();
             }
        });
          });


    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>