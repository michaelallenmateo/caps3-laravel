<!DOCTYPE html>
<html>
<head>
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<link rel="icon" type="image/gif/png" href="/image/tablogo.png">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="/css/template.css">
	<link rel="stylesheet" type="text/css" href="/css/product_details.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<!-- Fontawesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
  

	
</head>
<body>
	<nav class="navbar navbar-default">
	  <div class="container-fluid">
	    <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
	      <a class="navbar-brand" href="/"><img src="/image/mainlogo.png" id="mainlogo"></a>
	    </div>

      <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
	    <ul class="navbar-nav ml-auto">
	    		<?php $__currentLoopData = \App\Categories::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    	    	  <li class="categories">
    				    <a href="/products/category/<?php echo e($category->id); ?>">
    					     <li><?php echo e($category->title); ?></li>
    				    </a>
    		 	    </li>
		 		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <li class="categories">
            <a href="/">
              <li>ALL PRODUCTS</li>
            </a>
          <li>  
          
          <form action="/search_result" method="POST" role="search">
            <?php echo e(csrf_field()); ?>

            <div class="input-group search">
              <input type="text" class="form-control search" name="search"
                placeholder="Search products"> <span class="input-group-btn">
                <button type="submit" class="btn btn-default">
                  <span class="glyphicon glyphicon-search"></span>
                </button>
              </span>
            </div>
          </form>
          
      </ul>


	     <ul class="nav navbar-nav navbar-right">
	       <?php if(auth()->guard()->guest()): ?>
	          <li><a href="<?php echo e(route('login')); ?>">Login</a></li>
	          <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
         <?php else: ?>
	      	
	     </ul>
       <ul class="nav navbar-nav navbar-right">
          <li class="dropdown">
            <span class="profile_img"><img src="/storage/image/<?php echo e(Auth::user()->profile_image); ?>" id="profile_image"></span>
            <a href="#" class="dropdown-toggle pull-right" data-toggle="dropdown" role="button" aria-expanded="false" aria-haspopup="true">
                <?php echo e(Auth::user()->firstname); ?> <span class="caret"></span>
            </a>

            <ul class="dropdown-menu">
                <li class=""><a href="/myaccount">My Account</a></li>
                <li><a href="/myreviews">My Reviews </a></li>
                <li>
                    <a href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                        Logout
                    </a>

                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
                <li>
                    <a href="/changePassword/<?php echo e(Auth::user()->id); ?>">
                       Change Password
                    </a>
                </li>
            </ul>
          </li>
        </ul>
        <?php endif; ?>
	    </li>
	  </div>
  </div>
</nav>
	<?php echo $__env->yieldContent('content'); ?>

	
	  <!-- FOOTER START -->
<div class="footer">
  <div class="contain">
  <div class="col">
    <h1>Our Company</h1>
    <ul>
      <li>About</li>
      <li>Corporate Responsibility</li>
      <li>Careers</li>
    </ul>
  </div>
  <div class="col">
    <h1>Privacy Notice</h1>
    <ul>
      <li>Privacy Policy</li>
      <li>Terms and Condition</li>
    </ul>
  </div>
  <div class="col">
    <h1>SUPPORT</h1>
    <ul>
      <li>Contact Us</li>
      <li>Customer Support</li>

    </ul>
  </div>  

  <div class="col social">
    <h1>Social Accounts</h1>
    <ul>
      <li><img src="/image/instagram.png"></li>
      <li><img src="/image/fb.png"></li>
      <li><img src="/image/twitter.png"></li>
    </ul>
  </div>
<div class="clearfix"></div>
</div>
</div>
<!-- END OF FOOTER -->
</body>
</html>