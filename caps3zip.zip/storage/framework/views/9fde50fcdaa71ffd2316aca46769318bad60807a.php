<?php $__env->startSection('title','BeautyTalk | Latest Reviews and Trends on beauty products'); ?>
<?php $__env->startSection('content'); ?>

    
        <div class="container index">
        <div class="row">
                <?php if(isset($details)): ?>
                    <p> Matching results for your query <b> " <?php echo e($query); ?> " </b> are :</p>
                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="thumbnail">
                        <a href="/products/<?php echo e($product->id); ?>" style="list-style:none;">
                        <div class="col-xs-12">
                            <img src="/storage/image/<?php echo e($product->image); ?>" class="img-responsive">
                        </div>
                        </a>
                        <p><?php echo e($product->name); ?></p>
                        <p><?php echo e($product->brand); ?></p>
                        <p>&#8369 <?php echo e(number_format($product->price, 2)); ?></p>
                        <?php echo e($product->category->title); ?>

                        <div class="ratings">
                    
                            <?php for($i=1; $i <= 5 ; $i++): ?>
                              <span class="glyphicon glyphicon-star<?php echo e(($i <= $product->reviews->where('approved',true)->avg('rating')) ? '' : '-empty'); ?>"></span>
                            <?php endfor; ?>
                            
                            <p><strong><?php echo e(count($product->reviews->where('approved',true))); ?> Reviews</strong></p>
                        </div>
                    </div> 
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 <?php elseif(isset($message)): ?>
                    <p><?php echo e($message); ?></p>
                <?php endif; ?>
            </div>
        </div>



    <div style="border: 1px solid lightgrey;border-radius: 4px; width: 600px; position: fixed;bottom: 170px; top: auto; right:25%; background-color: #f7f7f7; display: inline-block; padding: 10px;" class="prodReview">
      <h4>Didn't find the product your looking? Submit the product you want to be reviewed.</h4>
      <div> <input type="text" name="prod_forReview" placeholder="Enter product name here"> </div>
      <div>  <button type="submit">Submit</button> </div>
    </div>


    <script type="text/javascript">
     



      $(document).ready( function() {
        $(".prodReview").hide(); //hide your div initially
        var y = $(this).scrollTop();
           $(window).scroll(function() {
             if($(window).scrollTop() > 300) {
              $('.prodReview').fadeIn();
              } else {
              $('.prodReview').fadeOut();
             }
        });
          });


    </script>


<?php $__env->stopSection(); ?>    



<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>