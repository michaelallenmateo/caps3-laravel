<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>

<h2>This is the admin page</h2>

</body>
</html>
