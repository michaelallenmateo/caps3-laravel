<?php $__env->startSection('title','BeautyTalk | Latest Reviews and Trends on beauty products'); ?>
<?php $__env->startSection('content'); ?>
 

    <div class="container index">
        <div class="row">
            
            <?php if(count($products)>0): ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4 col-lg-4 col-md-4">
                    <div class="thumbnail">
                        <a href="/products/<?php echo e($product->id); ?>" style="list-style:none;">
                        <div class="col-xs-12">
                            <img src="/storage/image/<?php echo e($product->image); ?>" class="img-responsive">
                        </div>
                        </a>
                        <p><?php echo e($product->name); ?></p>
                        <p><?php echo e($product->brand); ?></p>
                        <p>&#8369 <?php echo e(number_format($product->price, 2)); ?></p>
                        <?php echo e($product->category->title); ?>

                        <div class="ratings">
                            <strong>Rating:</strong>
                            <?php for($i=1; $i <= 5 ; $i++): ?>
                              <span class="glyphicon glyphicon-star<?php echo e(($i <= $product->reviews->avg('rating')) ? '' : '-empty'); ?>"></span>
                            <?php endfor; ?>
                            
                            <p><strong><?php echo e(count($product->reviews)); ?> Reviews</strong></p>
                        </div>
                    </div> 
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <h3>No listed products yet under this category</h3>
            <?php endif; ?>    
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>