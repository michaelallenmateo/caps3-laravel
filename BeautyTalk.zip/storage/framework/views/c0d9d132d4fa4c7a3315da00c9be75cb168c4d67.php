<?php $__env->startSection('title','BeautyTalk | Latest Reviews and Trends on beauty products'); ?>
<?php $__env->startSection('content'); ?>



<?php if($review->user_id == Auth::user()->id): ?>

<div class="container">
	<?php if(count($errors) > 0): ?>
		<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<p><?php echo e($error); ?></p>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?>


	<?php if(Session::has('success_message')): ?>
    <div class="alert alert-success">
      <?php echo e(Session::get('success_message')); ?>

    </div>
    <?php endif; ?>
	
	<h1>Edit review page</h1>

	<div>
	      <img type="image"  id="image" name="image" src="/image/<?php echo e($review->product->image); ?>" style="width: 200px;height: 200px;" >
	    

	
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="name">Name:</label>
		    <div class="col-sm-12">
		      <input type="text" class="form-control col-sm-6" id="name" name="name" value="<?php echo e($review->product->name); ?>" disabled="">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="brand">Brand:</label>
		    <div class="col-sm-12"> 
		    	<input class="form-control col-sm-12" rows="5" id="brand" name="brand" value="<?php echo e($review->product->brand); ?>" disabled="">
		    </div>
		  </div>
		  <div class="form-group">
		    <label class="control-label col-sm-2" for="price">Price:</label>
		    <div class="col-sm-12">
		      <input type="text"  class="form-control col-sm-6" id="price" name="price" value="&#8369 <?php echo e(number_format($review->product->price,2)); ?>" disabled="">
		    </div>
		  </div>
	    <div class="form-group">
	    	<label class="control-label col-sm-2" for="category">Category:</label>
	    	<div class="col-sm-12">
	  			<input type="text"  class="form-control col-sm-6" id="price" name="price" value="<?php echo e($review->product->category->title); ?>" disabled="" >
	    	</div>
	    </div>
	<form class="form-horizontal" method="POST">
	  <?php echo e(csrf_field()); ?>

	  <?php echo e(method_field('PATCH')); ?>

	  <input type="number" name="product_id" value="<?php echo e($review->product->id); ?>" hidden="">
	  <input type="number" name="user_id" value="<?php echo e($review->user->id); ?>" hidden="">
	  <div class="form-group">
	    	<label class="control-label col-sm-6" for="review_title">Your Review title:</label>
	    	<div class="col-sm-12">
	  			<input type="text"  class="form-control col-sm-6" id="review_title" name="review_title" value="<?php echo e($review->title); ?>" >
	    	</div>
	    </div>

	    <div class="form-group">
	    	<label class="control-label col-sm-6" for="review_content">Your Review content:</label>
	    	<div class="col-sm-12">
	  			<input type="text"  class="form-control col-sm-6" id="review_content" name="review_content" value="<?php echo e($review->content); ?>" >
	    	</div>
	    </div>

	    <div class="form-group">
	    	<label class="control-label col-sm-6" for="review_rating">Your Review star rating (1-5):</label>
	    	<div class="col-sm-12">
	  			<input type="number"  class="form-control col-sm-6" id="review_rating" name="review_rating" value="<?php echo e($review->rating); ?>" min="1" max="5">
	    	</div>
	    </div>
	    <input name="approved" value="0" readonly hidden></input>


	  <div class="form-group"> 
	    <div class="col-sm-offset-2 col-sm-10">
	      <button type="submit" class="btn btn-default">Submit</button>
	    </div>
	  </div>
	</form>
	</div> 
</div>


<?php else: ?> 
<div class="container">
<h4>You are not allowed to edit this review</h4>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>